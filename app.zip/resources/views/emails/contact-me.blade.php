@component('mail::message')

# A heading

Lorem ipsum dolor sit amen

- List
- goes
- here

@component('mail::button', ['url'=>'https://laracast.com'])
Visit Laracast
@endcomponent

@endcomponent