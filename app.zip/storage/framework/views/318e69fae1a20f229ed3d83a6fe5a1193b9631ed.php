

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><a href="/conversations/<?php echo e($conversation->id); ?>"> <?php echo e($conversation->title); ?> </a></h2>
        <?php if($loop->last) continue; ?>

        <hr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel6\resources\views/conversations/index.blade.php ENDPATH**/ ?>