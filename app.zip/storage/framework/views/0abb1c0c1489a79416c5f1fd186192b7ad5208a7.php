

<?php $__env->startSection('content'); ?>
<div class="container">
    Show all notifications!

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li> 
                <?php if($notification->type == 'App\Notifications\PaymentReceived'): ?>
                    We have received a Payment of $<?php echo e($notification->data['amount'] / 100); ?> from you. 
                <?php endif; ?>
               
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>You have no unread notifications at this time</li>       
        <?php endif; ?>
    </ul>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel6\resources\views/notifications/show.blade.php ENDPATH**/ ?>