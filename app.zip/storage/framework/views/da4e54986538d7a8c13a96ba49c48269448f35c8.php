

<?php $__env->startSection('content'); ?>

<div class="container">
    
    <p><a href="/conversations"> Back </a></p>

    <h1> <?php echo e($conversation->title); ?></h1>
    <p class="text-muted"> Posted by: <?php echo e($conversation->user->name); ?> </p>
    <div>
        <?php echo e($conversation->body); ?>

    </div>
    <?php echo $__env->make('conversations.replies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel6\resources\views/conversations/show.blade.php ENDPATH**/ ?>