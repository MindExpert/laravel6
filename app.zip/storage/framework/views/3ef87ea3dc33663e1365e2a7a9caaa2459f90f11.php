

<?php $__env->startSection('content'); ?>
<div class="container">
    <form method="POST" action="/payments">

      <?php echo csrf_field(); ?> 

        <button class="btn btn-primary" type="submit" formmethod="POST">Make Payment</button>
    </form>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel6\resources\views/payments/create.blade.php ENDPATH**/ ?>