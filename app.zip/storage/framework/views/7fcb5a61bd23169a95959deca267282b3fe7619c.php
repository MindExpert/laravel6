<?php $__currentLoopData = $conversation->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div>
        <p class="m-0"><strong><?php echo e($reply->user->name); ?> said... </strong></p>
        <?php echo e($reply->body); ?>

    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-conversation', $conversation)): ?>
        <form action="">
            <button class="btn btn-primary" type="submit">Best Reply</button>
        </form> 
    <?php endif; ?>
    <?php if($loop->last) continue; ?>
    <hr>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel6\resources\views/conversations/replies.blade.php ENDPATH**/ ?>