<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel6\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>